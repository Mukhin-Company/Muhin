﻿
namespace Nedvij.Nedvij
{
    partial class NedvAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.housebtn = new System.Windows.Forms.Button();
            this.apartbtn = new System.Windows.Forms.Button();
            this.landbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 27);
            this.label1.TabIndex = 4;
            this.label1.Text = "Добавление новой недвижимости";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(71, 40);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // housebtn
            // 
            this.housebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.housebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.housebtn.Location = new System.Drawing.Point(146, 228);
            this.housebtn.Name = "housebtn";
            this.housebtn.Size = new System.Drawing.Size(105, 47);
            this.housebtn.TabIndex = 24;
            this.housebtn.Text = "Добавить дом";
            this.housebtn.UseVisualStyleBackColor = false;
            this.housebtn.Click += new System.EventHandler(this.housebtn_Click);
            // 
            // apartbtn
            // 
            this.apartbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.apartbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apartbtn.Location = new System.Drawing.Point(146, 162);
            this.apartbtn.Name = "apartbtn";
            this.apartbtn.Size = new System.Drawing.Size(105, 47);
            this.apartbtn.TabIndex = 25;
            this.apartbtn.Text = "Добавить квартиру";
            this.apartbtn.UseVisualStyleBackColor = false;
            this.apartbtn.Click += new System.EventHandler(this.apartbtn_Click);
            // 
            // landbtn
            // 
            this.landbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.landbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.landbtn.Location = new System.Drawing.Point(146, 297);
            this.landbtn.Name = "landbtn";
            this.landbtn.Size = new System.Drawing.Size(105, 47);
            this.landbtn.TabIndex = 26;
            this.landbtn.Text = "Добавить землю";
            this.landbtn.UseVisualStyleBackColor = false;
            this.landbtn.Click += new System.EventHandler(this.landbtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(13, 391);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 47);
            this.button1.TabIndex = 27;
            this.button1.Text = "Домой";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // NedvAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(399, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.landbtn);
            this.Controls.Add(this.apartbtn);
            this.Controls.Add(this.housebtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "NedvAdd";
            this.Text = "Добавление недвижимости";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button housebtn;
        private System.Windows.Forms.Button apartbtn;
        private System.Windows.Forms.Button landbtn;
        private System.Windows.Forms.Button button1;
    }
}