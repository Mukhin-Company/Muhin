﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Nedvijim
{
    public partial class houseview : Form
    {
        public houseview()
        {
            InitializeComponent();
        }

        private void houseview_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.houses". При необходимости она может быть перемещена или удалена.
            this.housesTableAdapter1.Fill(this.nedvjDataSet1.houses);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet.houses". При необходимости она может быть перемещена или удалена.

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            Close();
        }

        private void filtrbtn_Click(object sender, EventArgs e)
        {
            housesBindingSource1.Filter = "[Address_City] Like'" + textBox1.Text + "%'";
        }
    }
}
