﻿
namespace Nedvij.Nedvijim
{
    partial class House
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backbtn = new System.Windows.Forms.Button();
            this.apartbtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.kolettxt = new System.Windows.Forms.TextBox();
            this.arealbl = new System.Windows.Forms.Label();
            this.totaretxt = new System.Windows.Forms.TextBox();
            this.numhlbl = new System.Windows.Forms.Label();
            this.numbhtxt = new System.Windows.Forms.TextBox();
            this.strlbl = new System.Windows.Forms.Label();
            this.strtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Adresstxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(13, 391);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 45;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // apartbtn
            // 
            this.apartbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.apartbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apartbtn.Location = new System.Drawing.Point(276, 331);
            this.apartbtn.Name = "apartbtn";
            this.apartbtn.Size = new System.Drawing.Size(105, 47);
            this.apartbtn.TabIndex = 44;
            this.apartbtn.Text = "Добавить дом";
            this.apartbtn.UseVisualStyleBackColor = false;
            this.apartbtn.Click += new System.EventHandler(this.apartbtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(133, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 19);
            this.label3.TabIndex = 41;
            this.label3.Text = "Кол-во этажей:";
            // 
            // kolettxt
            // 
            this.kolettxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kolettxt.Location = new System.Drawing.Point(249, 274);
            this.kolettxt.Name = "kolettxt";
            this.kolettxt.Size = new System.Drawing.Size(215, 26);
            this.kolettxt.TabIndex = 40;
            // 
            // arealbl
            // 
            this.arealbl.AutoSize = true;
            this.arealbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.arealbl.Location = new System.Drawing.Point(124, 238);
            this.arealbl.Name = "arealbl";
            this.arealbl.Size = new System.Drawing.Size(119, 19);
            this.arealbl.TabIndex = 39;
            this.arealbl.Text = "Общая площадь:";
            // 
            // totaretxt
            // 
            this.totaretxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.totaretxt.Location = new System.Drawing.Point(249, 231);
            this.totaretxt.Name = "totaretxt";
            this.totaretxt.Size = new System.Drawing.Size(215, 26);
            this.totaretxt.TabIndex = 38;
            // 
            // numhlbl
            // 
            this.numhlbl.AutoSize = true;
            this.numhlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numhlbl.Location = new System.Drawing.Point(151, 202);
            this.numhlbl.Name = "numhlbl";
            this.numhlbl.Size = new System.Drawing.Size(93, 19);
            this.numhlbl.TabIndex = 35;
            this.numhlbl.Text = "Номер дома:";
            // 
            // numbhtxt
            // 
            this.numbhtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbhtxt.Location = new System.Drawing.Point(249, 199);
            this.numbhtxt.Name = "numbhtxt";
            this.numbhtxt.Size = new System.Drawing.Size(215, 26);
            this.numbhtxt.TabIndex = 34;
            // 
            // strlbl
            // 
            this.strlbl.AutoSize = true;
            this.strlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strlbl.Location = new System.Drawing.Point(190, 174);
            this.strlbl.Name = "strlbl";
            this.strlbl.Size = new System.Drawing.Size(54, 19);
            this.strlbl.TabIndex = 33;
            this.strlbl.Text = "Улица:";
            // 
            // strtxt
            // 
            this.strtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strtxt.Location = new System.Drawing.Point(249, 167);
            this.strtxt.Name = "strtxt";
            this.strtxt.Size = new System.Drawing.Size(215, 26);
            this.strtxt.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(190, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 31;
            this.label2.Text = "Адрес:";
            // 
            // Adresstxt
            // 
            this.Adresstxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Adresstxt.Location = new System.Drawing.Point(249, 135);
            this.Adresstxt.Name = "Adresstxt";
            this.Adresstxt.Size = new System.Drawing.Size(215, 26);
            this.Adresstxt.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(8, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 27);
            this.label1.TabIndex = 29;
            this.label1.Text = "Добавление нового дома";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(13, 31);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // House
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(629, 450);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.apartbtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.kolettxt);
            this.Controls.Add(this.arealbl);
            this.Controls.Add(this.totaretxt);
            this.Controls.Add(this.numhlbl);
            this.Controls.Add(this.numbhtxt);
            this.Controls.Add(this.strlbl);
            this.Controls.Add(this.strtxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Adresstxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "House";
            this.Text = "Добавление нового дома";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Button apartbtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox kolettxt;
        private System.Windows.Forms.Label arealbl;
        private System.Windows.Forms.TextBox totaretxt;
        private System.Windows.Forms.Label numhlbl;
        private System.Windows.Forms.TextBox numbhtxt;
        private System.Windows.Forms.Label strlbl;
        private System.Windows.Forms.TextBox strtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Adresstxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}