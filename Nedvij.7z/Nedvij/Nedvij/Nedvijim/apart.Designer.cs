﻿
namespace Nedvij
{
    partial class apart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Adresstxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.strlbl = new System.Windows.Forms.Label();
            this.strtxt = new System.Windows.Forms.TextBox();
            this.numhlbl = new System.Windows.Forms.Label();
            this.numbhtxt = new System.Windows.Forms.TextBox();
            this.numbhoulbl = new System.Windows.Forms.Label();
            this.numbkvatxt = new System.Windows.Forms.TextBox();
            this.areatxt = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.kolkomtxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Etajtxt = new System.Windows.Forms.TextBox();
            this.apartbtn = new System.Windows.Forms.Button();
            this.backbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 27);
            this.label1.TabIndex = 6;
            this.label1.Text = "Добавление новой квартиры";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(13, 40);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Adresstxt
            // 
            this.Adresstxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Adresstxt.Location = new System.Drawing.Point(239, 170);
            this.Adresstxt.Name = "Adresstxt";
            this.Adresstxt.Size = new System.Drawing.Size(215, 26);
            this.Adresstxt.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(180, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Адрес:";
            // 
            // strlbl
            // 
            this.strlbl.AutoSize = true;
            this.strlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strlbl.Location = new System.Drawing.Point(180, 209);
            this.strlbl.Name = "strlbl";
            this.strlbl.Size = new System.Drawing.Size(54, 19);
            this.strlbl.TabIndex = 10;
            this.strlbl.Text = "Улица:";
            // 
            // strtxt
            // 
            this.strtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strtxt.Location = new System.Drawing.Point(239, 202);
            this.strtxt.Name = "strtxt";
            this.strtxt.Size = new System.Drawing.Size(215, 26);
            this.strtxt.TabIndex = 9;
            // 
            // numhlbl
            // 
            this.numhlbl.AutoSize = true;
            this.numhlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numhlbl.Location = new System.Drawing.Point(141, 237);
            this.numhlbl.Name = "numhlbl";
            this.numhlbl.Size = new System.Drawing.Size(93, 19);
            this.numhlbl.TabIndex = 12;
            this.numhlbl.Text = "Номер дома:";
            // 
            // numbhtxt
            // 
            this.numbhtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbhtxt.Location = new System.Drawing.Point(239, 234);
            this.numbhtxt.Name = "numbhtxt";
            this.numbhtxt.Size = new System.Drawing.Size(215, 26);
            this.numbhtxt.TabIndex = 11;
            // 
            // numbhoulbl
            // 
            this.numbhoulbl.AutoSize = true;
            this.numbhoulbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbhoulbl.Location = new System.Drawing.Point(109, 269);
            this.numbhoulbl.Name = "numbhoulbl";
            this.numbhoulbl.Size = new System.Drawing.Size(125, 19);
            this.numbhoulbl.TabIndex = 14;
            this.numbhoulbl.Text = "Номер квартиры:";
            // 
            // numbkvatxt
            // 
            this.numbkvatxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbkvatxt.Location = new System.Drawing.Point(239, 266);
            this.numbkvatxt.Name = "numbkvatxt";
            this.numbkvatxt.Size = new System.Drawing.Size(215, 26);
            this.numbkvatxt.TabIndex = 13;
            // 
            // areatxt
            // 
            this.areatxt.AutoSize = true;
            this.areatxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.areatxt.Location = new System.Drawing.Point(161, 301);
            this.areatxt.Name = "areatxt";
            this.areatxt.Size = new System.Drawing.Size(72, 19);
            this.areatxt.TabIndex = 16;
            this.areatxt.Text = "Площадь:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(239, 298);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(215, 26);
            this.textBox1.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(123, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 18;
            this.label3.Text = "Кол-во комнат:";
            // 
            // kolkomtxt
            // 
            this.kolkomtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kolkomtxt.Location = new System.Drawing.Point(239, 330);
            this.kolkomtxt.Name = "kolkomtxt";
            this.kolkomtxt.Size = new System.Drawing.Size(215, 26);
            this.kolkomtxt.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(180, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Этаж:";
            // 
            // Etajtxt
            // 
            this.Etajtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Etajtxt.Location = new System.Drawing.Point(239, 362);
            this.Etajtxt.Name = "Etajtxt";
            this.Etajtxt.Size = new System.Drawing.Size(215, 26);
            this.Etajtxt.TabIndex = 19;
            // 
            // apartbtn
            // 
            this.apartbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.apartbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apartbtn.Location = new System.Drawing.Point(279, 412);
            this.apartbtn.Name = "apartbtn";
            this.apartbtn.Size = new System.Drawing.Size(105, 47);
            this.apartbtn.TabIndex = 26;
            this.apartbtn.Text = "Добавить квартиру";
            this.apartbtn.UseVisualStyleBackColor = false;
            this.apartbtn.Click += new System.EventHandler(this.apartbtn_Click);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(18, 412);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 27;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // apart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(636, 471);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.apartbtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Etajtxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.kolkomtxt);
            this.Controls.Add(this.areatxt);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.numbhoulbl);
            this.Controls.Add(this.numbkvatxt);
            this.Controls.Add(this.numhlbl);
            this.Controls.Add(this.numbhtxt);
            this.Controls.Add(this.strlbl);
            this.Controls.Add(this.strtxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Adresstxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "apart";
            this.Text = "Добавление квартиры";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Adresstxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label strlbl;
        private System.Windows.Forms.TextBox strtxt;
        private System.Windows.Forms.Label numhlbl;
        private System.Windows.Forms.TextBox numbhtxt;
        private System.Windows.Forms.Label numbhoulbl;
        private System.Windows.Forms.TextBox numbkvatxt;
        private System.Windows.Forms.Label areatxt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox kolkomtxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Etajtxt;
        private System.Windows.Forms.Button apartbtn;
        private System.Windows.Forms.Button backbtn;
    }
}