﻿
namespace Nedvij.Nedvijim
{
    partial class houseview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backbtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.filtrbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressStreetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressHouseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalFloorsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.housesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nedvjDataSet = new nedvjDataSet();
            this.housesTableAdapter = new nedvjDataSetTableAdapters.housesTableAdapter();
            this.nedvjDataSet1 = new nedvjDataSet1();
            this.housesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.housesTableAdapter1 = new nedvjDataSet1TableAdapters.housesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.housesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.housesBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(13, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 27);
            this.label1.TabIndex = 10;
            this.label1.Text = "Просмотр домов";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(13, 42);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(18, 391);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 22;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(338, 76);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(239, 33);
            this.textBox1.TabIndex = 27;
            // 
            // filtrbtn
            // 
            this.filtrbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.filtrbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.filtrbtn.Location = new System.Drawing.Point(583, 76);
            this.filtrbtn.Name = "filtrbtn";
            this.filtrbtn.Size = new System.Drawing.Size(105, 33);
            this.filtrbtn.TabIndex = 26;
            this.filtrbtn.Text = "Поиск";
            this.filtrbtn.UseVisualStyleBackColor = false;
            this.filtrbtn.Click += new System.EventHandler(this.filtrbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.addressCityDataGridViewTextBoxColumn,
            this.addressStreetDataGridViewTextBoxColumn,
            this.addressHouseDataGridViewTextBoxColumn,
            this.totalFloorsDataGridViewTextBoxColumn,
            this.totalAreaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.housesBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(18, 156);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(729, 198);
            this.dataGridView1.TabIndex = 28;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // addressCityDataGridViewTextBoxColumn
            // 
            this.addressCityDataGridViewTextBoxColumn.DataPropertyName = "Address_City";
            this.addressCityDataGridViewTextBoxColumn.HeaderText = "Address_City";
            this.addressCityDataGridViewTextBoxColumn.Name = "addressCityDataGridViewTextBoxColumn";
            // 
            // addressStreetDataGridViewTextBoxColumn
            // 
            this.addressStreetDataGridViewTextBoxColumn.DataPropertyName = "Address_Street";
            this.addressStreetDataGridViewTextBoxColumn.HeaderText = "Address_Street";
            this.addressStreetDataGridViewTextBoxColumn.Name = "addressStreetDataGridViewTextBoxColumn";
            // 
            // addressHouseDataGridViewTextBoxColumn
            // 
            this.addressHouseDataGridViewTextBoxColumn.DataPropertyName = "Address_House";
            this.addressHouseDataGridViewTextBoxColumn.HeaderText = "Address_House";
            this.addressHouseDataGridViewTextBoxColumn.Name = "addressHouseDataGridViewTextBoxColumn";
            // 
            // totalFloorsDataGridViewTextBoxColumn
            // 
            this.totalFloorsDataGridViewTextBoxColumn.DataPropertyName = "TotalFloors";
            this.totalFloorsDataGridViewTextBoxColumn.HeaderText = "TotalFloors";
            this.totalFloorsDataGridViewTextBoxColumn.Name = "totalFloorsDataGridViewTextBoxColumn";
            // 
            // totalAreaDataGridViewTextBoxColumn
            // 
            this.totalAreaDataGridViewTextBoxColumn.DataPropertyName = "TotalArea";
            this.totalAreaDataGridViewTextBoxColumn.HeaderText = "TotalArea";
            this.totalAreaDataGridViewTextBoxColumn.Name = "totalAreaDataGridViewTextBoxColumn";
            // 
            // housesBindingSource
            // 
            this.housesBindingSource.DataMember = "houses";
            this.housesBindingSource.DataSource = this.nedvjDataSet;
            // 
            // nedvjDataSet
            // 
            this.nedvjDataSet.DataSetName = "nedvjDataSet";
            this.nedvjDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // housesTableAdapter
            // 
            this.housesTableAdapter.ClearBeforeFill = true;
            // 
            // nedvjDataSet1
            // 
            this.nedvjDataSet1.DataSetName = "nedvjDataSet1";
            this.nedvjDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // housesBindingSource1
            // 
            this.housesBindingSource1.DataMember = "houses";
            this.housesBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // housesTableAdapter1
            // 
            this.housesTableAdapter1.ClearBeforeFill = true;
            // 
            // houseview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.filtrbtn);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "houseview";
            this.Text = "Просмотр домов";
            this.Load += new System.EventHandler(this.houseview_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.housesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.housesBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button filtrbtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private nedvjDataSet nedvjDataSet;
        private System.Windows.Forms.BindingSource housesBindingSource;
        private nedvjDataSetTableAdapters.housesTableAdapter housesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressStreetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressHouseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalFloorsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalAreaDataGridViewTextBoxColumn;
        private nedvjDataSet1 nedvjDataSet1;
        private System.Windows.Forms.BindingSource housesBindingSource1;
        private nedvjDataSet1TableAdapters.housesTableAdapter housesTableAdapter1;
    }
}