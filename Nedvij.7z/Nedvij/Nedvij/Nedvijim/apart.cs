﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nedvij
{
    public partial class apart : Form
    {
        public apart()
        {
            InitializeComponent();
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }

        private void apartbtn_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.nedvjConnectionString1))
            {
                string str = @"Data Source=COMP3-A7\SQLEXPRESS;Initial Catalog=nedvj;Integrated Security=True";
                SqlConnection connection = new SqlConnection(str);
                connection.Open();

                SqlCommand command_insertClient = new SqlCommand("Insert into [apart](Address_City,Address_Street,Address_House,Address_Number,TotalArea,Rooms,Floor)" +
                    "Values(@Adress,@Ylica,@Numbdom,@Numkva,@Plosh,@Komnat,@Etaj)", connection);
                command_insertClient.Parameters.AddWithValue("@Adress", Adresstxt.Text);
                command_insertClient.Parameters.AddWithValue("@Ylica", strtxt.Text);
                command_insertClient.Parameters.AddWithValue("@Numbdom", numbhtxt.Text);
                command_insertClient.Parameters.AddWithValue("@Numkva", numbkvatxt.Text);
                command_insertClient.Parameters.AddWithValue("@Plosh", textBox1.Text);
                command_insertClient.Parameters.AddWithValue("@Komnat", kolkomtxt.Text);
                command_insertClient.Parameters.AddWithValue("@Etaj", Etajtxt.Text);
                command_insertClient.ExecuteNonQuery()
;
                try
                {
                    MessageBox.Show("Добавление квартиры успешно", "Добавление");
                }
                catch
                {
                    MessageBox.Show("Проверьте введенные ланные!", "Ошибка");
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
