﻿
namespace Nedvij.Nedvijim
{
    partial class apartview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressStreetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressHouseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.floorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apartBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.nedvjDataSet = new nedvjDataSet();
            this.apartBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apartTableAdapter = new nedvjDataSetTableAdapters.apartTableAdapter();
            this.apartBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.filtrbtn = new System.Windows.Forms.Button();
            this.backbtn = new System.Windows.Forms.Button();
            this.nedvjDataSet1 = new nedvjDataSet1();
            this.apartBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.apartTableAdapter1 = new nedvjDataSet1TableAdapters.apartTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(22, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 27);
            this.label1.TabIndex = 8;
            this.label1.Text = "Просмотр квартир";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(22, 48);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.addressCityDataGridViewTextBoxColumn,
            this.addressStreetDataGridViewTextBoxColumn,
            this.addressHouseDataGridViewTextBoxColumn,
            this.addressNumberDataGridViewTextBoxColumn,
            this.totalAreaDataGridViewTextBoxColumn,
            this.roomsDataGridViewTextBoxColumn,
            this.floorDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.apartBindingSource3;
            this.dataGridView1.Location = new System.Drawing.Point(22, 152);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(845, 228);
            this.dataGridView1.TabIndex = 9;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // addressCityDataGridViewTextBoxColumn
            // 
            this.addressCityDataGridViewTextBoxColumn.DataPropertyName = "Address_City";
            this.addressCityDataGridViewTextBoxColumn.HeaderText = "Address_City";
            this.addressCityDataGridViewTextBoxColumn.Name = "addressCityDataGridViewTextBoxColumn";
            // 
            // addressStreetDataGridViewTextBoxColumn
            // 
            this.addressStreetDataGridViewTextBoxColumn.DataPropertyName = "Address_Street";
            this.addressStreetDataGridViewTextBoxColumn.HeaderText = "Address_Street";
            this.addressStreetDataGridViewTextBoxColumn.Name = "addressStreetDataGridViewTextBoxColumn";
            // 
            // addressHouseDataGridViewTextBoxColumn
            // 
            this.addressHouseDataGridViewTextBoxColumn.DataPropertyName = "Address_House";
            this.addressHouseDataGridViewTextBoxColumn.HeaderText = "Address_House";
            this.addressHouseDataGridViewTextBoxColumn.Name = "addressHouseDataGridViewTextBoxColumn";
            // 
            // addressNumberDataGridViewTextBoxColumn
            // 
            this.addressNumberDataGridViewTextBoxColumn.DataPropertyName = "Address_Number";
            this.addressNumberDataGridViewTextBoxColumn.HeaderText = "Address_Number";
            this.addressNumberDataGridViewTextBoxColumn.Name = "addressNumberDataGridViewTextBoxColumn";
            // 
            // totalAreaDataGridViewTextBoxColumn
            // 
            this.totalAreaDataGridViewTextBoxColumn.DataPropertyName = "TotalArea";
            this.totalAreaDataGridViewTextBoxColumn.HeaderText = "TotalArea";
            this.totalAreaDataGridViewTextBoxColumn.Name = "totalAreaDataGridViewTextBoxColumn";
            // 
            // roomsDataGridViewTextBoxColumn
            // 
            this.roomsDataGridViewTextBoxColumn.DataPropertyName = "Rooms";
            this.roomsDataGridViewTextBoxColumn.HeaderText = "Rooms";
            this.roomsDataGridViewTextBoxColumn.Name = "roomsDataGridViewTextBoxColumn";
            // 
            // floorDataGridViewTextBoxColumn
            // 
            this.floorDataGridViewTextBoxColumn.DataPropertyName = "Floor";
            this.floorDataGridViewTextBoxColumn.HeaderText = "Floor";
            this.floorDataGridViewTextBoxColumn.Name = "floorDataGridViewTextBoxColumn";
            // 
            // apartBindingSource2
            // 
            this.apartBindingSource2.DataMember = "apart";
            this.apartBindingSource2.DataSource = this.nedvjDataSet;
            // 
            // nedvjDataSet
            // 
            this.nedvjDataSet.DataSetName = "nedvjDataSet";
            this.nedvjDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apartBindingSource
            // 
            this.apartBindingSource.DataMember = "apart";
            this.apartBindingSource.DataSource = this.nedvjDataSet;
            // 
            // apartTableAdapter
            // 
            this.apartTableAdapter.ClearBeforeFill = true;
            // 
            // apartBindingSource1
            // 
            this.apartBindingSource1.DataMember = "apart";
            this.apartBindingSource1.DataSource = this.nedvjDataSet;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(423, 48);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(239, 33);
            this.textBox1.TabIndex = 25;
            // 
            // filtrbtn
            // 
            this.filtrbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.filtrbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.filtrbtn.Location = new System.Drawing.Point(668, 48);
            this.filtrbtn.Name = "filtrbtn";
            this.filtrbtn.Size = new System.Drawing.Size(105, 33);
            this.filtrbtn.TabIndex = 24;
            this.filtrbtn.Text = "Поиск";
            this.filtrbtn.UseVisualStyleBackColor = false;
            this.filtrbtn.Click += new System.EventHandler(this.filtrbtn_Click);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(27, 412);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 26;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // nedvjDataSet1
            // 
            this.nedvjDataSet1.DataSetName = "nedvjDataSet1";
            this.nedvjDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apartBindingSource3
            // 
            this.apartBindingSource3.DataMember = "apart";
            this.apartBindingSource3.DataSource = this.nedvjDataSet1;
            // 
            // apartTableAdapter1
            // 
            this.apartTableAdapter1.ClearBeforeFill = true;
            // 
            // apartview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(886, 481);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.filtrbtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "apartview";
            this.Text = "Просмотр квартир";
            this.Load += new System.EventHandler(this.apartview_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.BindingSource apartBindingSource;
        private System.Windows.Forms.BindingSource apartBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressStreetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressHouseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalAreaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn floorDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource apartBindingSource2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button filtrbtn;
        private System.Windows.Forms.Button backbtn;
        private nedvjDataSet nedvjDataSet;
        private nedvjDataSetTableAdapters.apartTableAdapter apartTableAdapter;
        private nedvjDataSet1 nedvjDataSet1;
        private System.Windows.Forms.BindingSource apartBindingSource3;
        private nedvjDataSet1TableAdapters.apartTableAdapter apartTableAdapter1;
    }
}