﻿
namespace Nedvij.Nedvijim
{
    partial class land
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backbtn = new System.Windows.Forms.Button();
            this.apartbtn = new System.Windows.Forms.Button();
            this.arealbl = new System.Windows.Forms.Label();
            this.totaretxt = new System.Windows.Forms.TextBox();
            this.strlbl = new System.Windows.Forms.Label();
            this.strtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Adresstxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(13, 398);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 59;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // apartbtn
            // 
            this.apartbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.apartbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apartbtn.Location = new System.Drawing.Point(219, 293);
            this.apartbtn.Name = "apartbtn";
            this.apartbtn.Size = new System.Drawing.Size(105, 47);
            this.apartbtn.TabIndex = 58;
            this.apartbtn.Text = "Добавить землю";
            this.apartbtn.UseVisualStyleBackColor = false;
            this.apartbtn.Click += new System.EventHandler(this.apartbtn_Click);
            // 
            // arealbl
            // 
            this.arealbl.AutoSize = true;
            this.arealbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.arealbl.Location = new System.Drawing.Point(41, 240);
            this.arealbl.Name = "arealbl";
            this.arealbl.Size = new System.Drawing.Size(119, 19);
            this.arealbl.TabIndex = 55;
            this.arealbl.Text = "Общая площадь:";
            // 
            // totaretxt
            // 
            this.totaretxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.totaretxt.Location = new System.Drawing.Point(166, 237);
            this.totaretxt.Name = "totaretxt";
            this.totaretxt.Size = new System.Drawing.Size(215, 26);
            this.totaretxt.TabIndex = 54;
            // 
            // strlbl
            // 
            this.strlbl.AutoSize = true;
            this.strlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strlbl.Location = new System.Drawing.Point(106, 201);
            this.strlbl.Name = "strlbl";
            this.strlbl.Size = new System.Drawing.Size(54, 19);
            this.strlbl.TabIndex = 51;
            this.strlbl.Text = "Улица:";
            // 
            // strtxt
            // 
            this.strtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strtxt.Location = new System.Drawing.Point(165, 194);
            this.strtxt.Name = "strtxt";
            this.strtxt.Size = new System.Drawing.Size(215, 26);
            this.strtxt.TabIndex = 50;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(106, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 49;
            this.label2.Text = "Адрес:";
            // 
            // Adresstxt
            // 
            this.Adresstxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Adresstxt.Location = new System.Drawing.Point(165, 162);
            this.Adresstxt.Name = "Adresstxt";
            this.Adresstxt.Size = new System.Drawing.Size(215, 26);
            this.Adresstxt.TabIndex = 48;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(8, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 27);
            this.label1.TabIndex = 47;
            this.label1.Text = "Добавление новой земли";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(13, 38);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            // 
            // land
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(514, 450);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.apartbtn);
            this.Controls.Add(this.arealbl);
            this.Controls.Add(this.totaretxt);
            this.Controls.Add(this.strlbl);
            this.Controls.Add(this.strtxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Adresstxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "land";
            this.Text = "Добавление нового участка земли";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Button apartbtn;
        private System.Windows.Forms.Label arealbl;
        private System.Windows.Forms.TextBox totaretxt;
        private System.Windows.Forms.Label strlbl;
        private System.Windows.Forms.TextBox strtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Adresstxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}