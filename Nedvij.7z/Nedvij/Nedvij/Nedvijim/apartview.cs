﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Nedvijim
{
    public partial class apartview : Form
    {
        public apartview()
        {
            InitializeComponent();
        }

        private void apartview_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.apart". При необходимости она может быть перемещена или удалена.
            this.apartTableAdapter1.Fill(this.nedvjDataSet1.apart);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet.apart". При необходимости она может быть перемещена или удалена.

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            Close();
        }

        private void filtrbtn_Click(object sender, EventArgs e)
        {
            apartBindingSource3.Filter = "[Address_City] Like'" + textBox1.Text + "%'";
        }

    }
}
