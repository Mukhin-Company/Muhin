﻿
namespace Nedvij
{
    partial class MainWindow
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.клиентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьКлиентаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменениеИнфКлиентаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.риToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйРиэлторToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменениеИнфриэлтораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.недвижимостьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьОбъектНедвижимостиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьОбъектНедвижимостиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.предложениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьПредложениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьПредложениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.потребностьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьПотребностьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьПотребностьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.клиентToolStripMenuItem,
            this.риToolStripMenuItem,
            this.недвижимостьToolStripMenuItem,
            this.предложениеToolStripMenuItem,
            this.потребностьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(732, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // клиентToolStripMenuItem
            // 
            this.клиентToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьКлиентаToolStripMenuItem,
            this.изменениеИнфКлиентаToolStripMenuItem});
            this.клиентToolStripMenuItem.Name = "клиентToolStripMenuItem";
            this.клиентToolStripMenuItem.Size = new System.Drawing.Size(72, 23);
            this.клиентToolStripMenuItem.Text = "Клиент";
            // 
            // создатьКлиентаToolStripMenuItem
            // 
            this.создатьКлиентаToolStripMenuItem.Name = "создатьКлиентаToolStripMenuItem";
            this.создатьКлиентаToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.создатьКлиентаToolStripMenuItem.Text = "Создать клиента";
            this.создатьКлиентаToolStripMenuItem.Click += new System.EventHandler(this.создатьКлиентаToolStripMenuItem_Click);
            // 
            // изменениеИнфКлиентаToolStripMenuItem
            // 
            this.изменениеИнфКлиентаToolStripMenuItem.Name = "изменениеИнфКлиентаToolStripMenuItem";
            this.изменениеИнфКлиентаToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.изменениеИнфКлиентаToolStripMenuItem.Text = "Изменение инф. клиента";
            this.изменениеИнфКлиентаToolStripMenuItem.Click += new System.EventHandler(this.изменениеИнфКлиентаToolStripMenuItem_Click);
            // 
            // риToolStripMenuItem
            // 
            this.риToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыйРиэлторToolStripMenuItem,
            this.изменениеИнфриэлтораToolStripMenuItem});
            this.риToolStripMenuItem.Name = "риToolStripMenuItem";
            this.риToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.риToolStripMenuItem.Text = "Риэлтор";
            // 
            // новыйРиэлторToolStripMenuItem
            // 
            this.новыйРиэлторToolStripMenuItem.Name = "новыйРиэлторToolStripMenuItem";
            this.новыйРиэлторToolStripMenuItem.Size = new System.Drawing.Size(250, 24);
            this.новыйРиэлторToolStripMenuItem.Text = "Новый риэлтор";
            this.новыйРиэлторToolStripMenuItem.Click += new System.EventHandler(this.новыйРиэлторToolStripMenuItem_Click);
            // 
            // изменениеИнфриэлтораToolStripMenuItem
            // 
            this.изменениеИнфриэлтораToolStripMenuItem.Name = "изменениеИнфриэлтораToolStripMenuItem";
            this.изменениеИнфриэлтораToolStripMenuItem.Size = new System.Drawing.Size(250, 24);
            this.изменениеИнфриэлтораToolStripMenuItem.Text = "Изменение инф.риэлтора";
            this.изменениеИнфриэлтораToolStripMenuItem.Click += new System.EventHandler(this.изменениеИнфриэлтораToolStripMenuItem_Click);
            // 
            // недвижимостьToolStripMenuItem
            // 
            this.недвижимостьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьОбъектНедвижимостиToolStripMenuItem,
            this.редактироватьОбъектНедвижимостиToolStripMenuItem});
            this.недвижимостьToolStripMenuItem.Name = "недвижимостьToolStripMenuItem";
            this.недвижимостьToolStripMenuItem.Size = new System.Drawing.Size(123, 23);
            this.недвижимостьToolStripMenuItem.Text = "Недвижимость";
            // 
            // создатьОбъектНедвижимостиToolStripMenuItem
            // 
            this.создатьОбъектНедвижимостиToolStripMenuItem.Name = "создатьОбъектНедвижимостиToolStripMenuItem";
            this.создатьОбъектНедвижимостиToolStripMenuItem.Size = new System.Drawing.Size(332, 24);
            this.создатьОбъектНедвижимостиToolStripMenuItem.Text = "Создать объект недвижимости";
            this.создатьОбъектНедвижимостиToolStripMenuItem.Click += new System.EventHandler(this.создатьОбъектНедвижимостиToolStripMenuItem_Click);
            // 
            // редактироватьОбъектНедвижимостиToolStripMenuItem
            // 
            this.редактироватьОбъектНедвижимостиToolStripMenuItem.Name = "редактироватьОбъектНедвижимостиToolStripMenuItem";
            this.редактироватьОбъектНедвижимостиToolStripMenuItem.Size = new System.Drawing.Size(332, 24);
            this.редактироватьОбъектНедвижимостиToolStripMenuItem.Text = "Редактировать объект недвижимости";
            this.редактироватьОбъектНедвижимостиToolStripMenuItem.Click += new System.EventHandler(this.редактироватьОбъектНедвижимостиToolStripMenuItem_Click);
            // 
            // предложениеToolStripMenuItem
            // 
            this.предложениеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьПредложениеToolStripMenuItem,
            this.редактироватьПредложениеToolStripMenuItem});
            this.предложениеToolStripMenuItem.Name = "предложениеToolStripMenuItem";
            this.предложениеToolStripMenuItem.Size = new System.Drawing.Size(114, 23);
            this.предложениеToolStripMenuItem.Text = "Предложение";
            // 
            // создатьПредложениеToolStripMenuItem
            // 
            this.создатьПредложениеToolStripMenuItem.Name = "создатьПредложениеToolStripMenuItem";
            this.создатьПредложениеToolStripMenuItem.Size = new System.Drawing.Size(272, 24);
            this.создатьПредложениеToolStripMenuItem.Text = "Создать предложение";
            this.создатьПредложениеToolStripMenuItem.Click += new System.EventHandler(this.создатьПредложениеToolStripMenuItem_Click);
            // 
            // редактироватьПредложениеToolStripMenuItem
            // 
            this.редактироватьПредложениеToolStripMenuItem.Name = "редактироватьПредложениеToolStripMenuItem";
            this.редактироватьПредложениеToolStripMenuItem.Size = new System.Drawing.Size(272, 24);
            this.редактироватьПредложениеToolStripMenuItem.Text = "Редактировать предложение";
            this.редактироватьПредложениеToolStripMenuItem.Click += new System.EventHandler(this.редактироватьПредложениеToolStripMenuItem_Click);
            // 
            // потребностьToolStripMenuItem
            // 
            this.потребностьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьПотребностьToolStripMenuItem,
            this.редактироватьПотребностьToolStripMenuItem});
            this.потребностьToolStripMenuItem.Name = "потребностьToolStripMenuItem";
            this.потребностьToolStripMenuItem.Size = new System.Drawing.Size(108, 23);
            this.потребностьToolStripMenuItem.Text = "Потребность";
            // 
            // создатьПотребностьToolStripMenuItem
            // 
            this.создатьПотребностьToolStripMenuItem.Name = "создатьПотребностьToolStripMenuItem";
            this.создатьПотребностьToolStripMenuItem.Size = new System.Drawing.Size(266, 24);
            this.создатьПотребностьToolStripMenuItem.Text = "Создать потребность";
            this.создатьПотребностьToolStripMenuItem.Click += new System.EventHandler(this.создатьПотребностьToolStripMenuItem_Click);
            // 
            // редактироватьПотребностьToolStripMenuItem
            // 
            this.редактироватьПотребностьToolStripMenuItem.Name = "редактироватьПотребностьToolStripMenuItem";
            this.редактироватьПотребностьToolStripMenuItem.Size = new System.Drawing.Size(266, 24);
            this.редактироватьПотребностьToolStripMenuItem.Text = "Редактировать потребность";
            this.редактироватьПотребностьToolStripMenuItem.Click += new System.EventHandler(this.редактироватьПотребностьToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(211, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 27);
            this.label1.TabIndex = 2;
            this.label1.Text = "Агенство недвижимости";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(216, 60);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(732, 189);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainWindow";
            this.Text = "Главный экран";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem клиентToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьКлиентаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменениеИнфКлиентаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem риToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новыйРиэлторToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменениеИнфриэлтораToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem недвижимостьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьОбъектНедвижимостиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьОбъектНедвижимостиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem предложениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьПредложениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьПредложениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem потребностьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьПотребностьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьПотребностьToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}

