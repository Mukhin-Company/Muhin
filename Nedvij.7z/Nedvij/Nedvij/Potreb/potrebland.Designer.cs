﻿
namespace Nedvij.Potreb
{
    partial class potrebland
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.maxareatxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.minareatxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.maxprtxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.minprtxt = new System.Windows.Forms.TextBox();
            this.strlbl = new System.Windows.Forms.Label();
            this.strtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Adresstxt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.backbtn = new System.Windows.Forms.Button();
            this.apartbtn = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.clientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nedvjDataSet = new nedvjDataSet();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.agentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.agentsTableAdapter = new nedvjDataSetTableAdapters.agentsTableAdapter();
            this.clientsTableAdapter = new nedvjDataSetTableAdapters.clientsTableAdapter();
            this.nedvjDataSet1 = new nedvjDataSet1();
            this.agentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.agentsTableAdapter1 = new nedvjDataSet1TableAdapters.agentsTableAdapter();
            this.clientsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.clientsTableAdapter1 = new nedvjDataSet1TableAdapters.clientsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(7, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(371, 27);
            this.label1.TabIndex = 31;
            this.label1.Text = "Добавление потребности на землю";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(30, 37);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(104, 310);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 19);
            this.label7.TabIndex = 87;
            this.label7.Text = "Максимальная площадь:";
            // 
            // maxareatxt
            // 
            this.maxareatxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maxareatxt.Location = new System.Drawing.Point(283, 307);
            this.maxareatxt.Name = "maxareatxt";
            this.maxareatxt.Size = new System.Drawing.Size(215, 26);
            this.maxareatxt.TabIndex = 86;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(107, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 19);
            this.label6.TabIndex = 85;
            this.label6.Text = "Минимальная площадь:";
            // 
            // minareatxt
            // 
            this.minareatxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minareatxt.Location = new System.Drawing.Point(283, 275);
            this.minareatxt.Name = "minareatxt";
            this.minareatxt.Size = new System.Drawing.Size(215, 26);
            this.minareatxt.TabIndex = 84;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(94, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 19);
            this.label5.TabIndex = 83;
            this.label5.Text = "Максимальная стоимость:";
            // 
            // maxprtxt
            // 
            this.maxprtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maxprtxt.Location = new System.Drawing.Point(283, 243);
            this.maxprtxt.Name = "maxprtxt";
            this.maxprtxt.Size = new System.Drawing.Size(215, 26);
            this.maxprtxt.TabIndex = 82;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(97, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 19);
            this.label4.TabIndex = 81;
            this.label4.Text = "Минимальная стоимость:";
            // 
            // minprtxt
            // 
            this.minprtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minprtxt.Location = new System.Drawing.Point(283, 211);
            this.minprtxt.Name = "minprtxt";
            this.minprtxt.Size = new System.Drawing.Size(215, 26);
            this.minprtxt.TabIndex = 80;
            // 
            // strlbl
            // 
            this.strlbl.AutoSize = true;
            this.strlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strlbl.Location = new System.Drawing.Point(224, 187);
            this.strlbl.Name = "strlbl";
            this.strlbl.Size = new System.Drawing.Size(54, 19);
            this.strlbl.TabIndex = 73;
            this.strlbl.Text = "Улица:";
            // 
            // strtxt
            // 
            this.strtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strtxt.Location = new System.Drawing.Point(283, 180);
            this.strtxt.Name = "strtxt";
            this.strtxt.Size = new System.Drawing.Size(215, 26);
            this.strtxt.TabIndex = 72;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(224, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 71;
            this.label2.Text = "Адрес:";
            // 
            // Adresstxt
            // 
            this.Adresstxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Adresstxt.Location = new System.Drawing.Point(283, 148);
            this.Adresstxt.Name = "Adresstxt";
            this.Adresstxt.Size = new System.Drawing.Size(215, 26);
            this.Adresstxt.TabIndex = 70;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(381, 84);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 19);
            this.label11.TabIndex = 95;
            this.label11.Text = "Номер клиента:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(381, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 19);
            this.label10.TabIndex = 93;
            this.label10.Text = "Номер риэтора:";
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(30, 404);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 97;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // apartbtn
            // 
            this.apartbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.apartbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apartbtn.Location = new System.Drawing.Point(325, 349);
            this.apartbtn.Name = "apartbtn";
            this.apartbtn.Size = new System.Drawing.Size(105, 47);
            this.apartbtn.TabIndex = 96;
            this.apartbtn.Text = "Добавить землю";
            this.apartbtn.UseVisualStyleBackColor = false;
            this.apartbtn.Click += new System.EventHandler(this.apartbtn_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.clientsBindingSource1;
            this.comboBox2.DisplayMember = "Id";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(502, 84);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(80, 21);
            this.comboBox2.TabIndex = 99;
            // 
            // clientsBindingSource
            // 
            this.clientsBindingSource.DataMember = "clients";
            this.clientsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // nedvjDataSet
            // 
            this.nedvjDataSet.DataSetName = "nedvjDataSet";
            this.nedvjDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.agentsBindingSource1;
            this.comboBox1.DisplayMember = "Id";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(501, 53);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(81, 21);
            this.comboBox1.TabIndex = 98;
            // 
            // agentsBindingSource
            // 
            this.agentsBindingSource.DataMember = "agents";
            this.agentsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // agentsTableAdapter
            // 
            this.agentsTableAdapter.ClearBeforeFill = true;
            // 
            // clientsTableAdapter
            // 
            this.clientsTableAdapter.ClearBeforeFill = true;
            // 
            // nedvjDataSet1
            // 
            this.nedvjDataSet1.DataSetName = "nedvjDataSet1";
            this.nedvjDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // agentsBindingSource1
            // 
            this.agentsBindingSource1.DataMember = "agents";
            this.agentsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // agentsTableAdapter1
            // 
            this.agentsTableAdapter1.ClearBeforeFill = true;
            // 
            // clientsBindingSource1
            // 
            this.clientsBindingSource1.DataMember = "clients";
            this.clientsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // clientsTableAdapter1
            // 
            this.clientsTableAdapter1.ClearBeforeFill = true;
            // 
            // potrebland
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(640, 457);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.apartbtn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.maxareatxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.minareatxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.maxprtxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.minprtxt);
            this.Controls.Add(this.strlbl);
            this.Controls.Add(this.strtxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Adresstxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "potrebland";
            this.Text = "Потребность на землю";
            this.Load += new System.EventHandler(this.potrebland_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox maxareatxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox minareatxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox maxprtxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox minprtxt;
        private System.Windows.Forms.Label strlbl;
        private System.Windows.Forms.TextBox strtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Adresstxt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Button apartbtn;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private nedvjDataSet nedvjDataSet;
        private System.Windows.Forms.BindingSource agentsBindingSource;
        private nedvjDataSetTableAdapters.agentsTableAdapter agentsTableAdapter;
        private System.Windows.Forms.BindingSource clientsBindingSource;
        private nedvjDataSetTableAdapters.clientsTableAdapter clientsTableAdapter;
        private nedvjDataSet1 nedvjDataSet1;
        private System.Windows.Forms.BindingSource agentsBindingSource1;
        private nedvjDataSet1TableAdapters.agentsTableAdapter agentsTableAdapter1;
        private System.Windows.Forms.BindingSource clientsBindingSource1;
        private nedvjDataSet1TableAdapters.clientsTableAdapter clientsTableAdapter1;
    }
}