﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Potreb
{
    public partial class PotrebAdd : Form
    {
        public PotrebAdd()
        {
            InitializeComponent();
        }

        private void housebtn_Click(object sender, EventArgs e)
        {
            Form a = new potrebhouse();
            a.Show();
            this.Close();
        }

        private void apartbtn_Click(object sender, EventArgs e)
        {
            Form a = new potrebapart();
            a.Show();
            this.Close();
        }

        private void landbtn_Click(object sender, EventArgs e)
        {
            Form a = new potrebland();
            a.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }
    }
}
