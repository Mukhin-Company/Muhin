﻿
namespace Nedvij.Potreb
{
    partial class landsv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressStreetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressHouseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maxPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.agentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maxAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.landdemandsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nedvjDataSet = new nedvjDataSet();
            this.land_demandsTableAdapter = new nedvjDataSetTableAdapters.land_demandsTableAdapter();
            this.nedvjDataSet1 = new nedvjDataSet1();
            this.landdemandsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.land_demandsTableAdapter1 = new nedvjDataSet1TableAdapters.land_demandsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.landdemandsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.landdemandsBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(6, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 27);
            this.label1.TabIndex = 35;
            this.label1.Text = "Просмотр потребности на землю";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(25, 36);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(25, 391);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 98;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.addressCityDataGridViewTextBoxColumn,
            this.addressStreetDataGridViewTextBoxColumn,
            this.addressHouseDataGridViewTextBoxColumn,
            this.addressNumberDataGridViewTextBoxColumn,
            this.minPriceDataGridViewTextBoxColumn,
            this.maxPriceDataGridViewTextBoxColumn,
            this.agentIdDataGridViewTextBoxColumn,
            this.clientIdDataGridViewTextBoxColumn,
            this.minAreaDataGridViewTextBoxColumn,
            this.maxAreaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.landdemandsBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(11, 140);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(906, 233);
            this.dataGridView1.TabIndex = 99;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // addressCityDataGridViewTextBoxColumn
            // 
            this.addressCityDataGridViewTextBoxColumn.DataPropertyName = "Address_City";
            this.addressCityDataGridViewTextBoxColumn.HeaderText = "Address_City";
            this.addressCityDataGridViewTextBoxColumn.Name = "addressCityDataGridViewTextBoxColumn";
            // 
            // addressStreetDataGridViewTextBoxColumn
            // 
            this.addressStreetDataGridViewTextBoxColumn.DataPropertyName = "Address_Street";
            this.addressStreetDataGridViewTextBoxColumn.HeaderText = "Address_Street";
            this.addressStreetDataGridViewTextBoxColumn.Name = "addressStreetDataGridViewTextBoxColumn";
            // 
            // addressHouseDataGridViewTextBoxColumn
            // 
            this.addressHouseDataGridViewTextBoxColumn.DataPropertyName = "Address_House";
            this.addressHouseDataGridViewTextBoxColumn.HeaderText = "Address_House";
            this.addressHouseDataGridViewTextBoxColumn.Name = "addressHouseDataGridViewTextBoxColumn";
            // 
            // addressNumberDataGridViewTextBoxColumn
            // 
            this.addressNumberDataGridViewTextBoxColumn.DataPropertyName = "Address_Number";
            this.addressNumberDataGridViewTextBoxColumn.HeaderText = "Address_Number";
            this.addressNumberDataGridViewTextBoxColumn.Name = "addressNumberDataGridViewTextBoxColumn";
            // 
            // minPriceDataGridViewTextBoxColumn
            // 
            this.minPriceDataGridViewTextBoxColumn.DataPropertyName = "MinPrice";
            this.minPriceDataGridViewTextBoxColumn.HeaderText = "MinPrice";
            this.minPriceDataGridViewTextBoxColumn.Name = "minPriceDataGridViewTextBoxColumn";
            // 
            // maxPriceDataGridViewTextBoxColumn
            // 
            this.maxPriceDataGridViewTextBoxColumn.DataPropertyName = "MaxPrice";
            this.maxPriceDataGridViewTextBoxColumn.HeaderText = "MaxPrice";
            this.maxPriceDataGridViewTextBoxColumn.Name = "maxPriceDataGridViewTextBoxColumn";
            // 
            // agentIdDataGridViewTextBoxColumn
            // 
            this.agentIdDataGridViewTextBoxColumn.DataPropertyName = "AgentId";
            this.agentIdDataGridViewTextBoxColumn.HeaderText = "AgentId";
            this.agentIdDataGridViewTextBoxColumn.Name = "agentIdDataGridViewTextBoxColumn";
            // 
            // clientIdDataGridViewTextBoxColumn
            // 
            this.clientIdDataGridViewTextBoxColumn.DataPropertyName = "ClientId";
            this.clientIdDataGridViewTextBoxColumn.HeaderText = "ClientId";
            this.clientIdDataGridViewTextBoxColumn.Name = "clientIdDataGridViewTextBoxColumn";
            // 
            // minAreaDataGridViewTextBoxColumn
            // 
            this.minAreaDataGridViewTextBoxColumn.DataPropertyName = "MinArea";
            this.minAreaDataGridViewTextBoxColumn.HeaderText = "MinArea";
            this.minAreaDataGridViewTextBoxColumn.Name = "minAreaDataGridViewTextBoxColumn";
            // 
            // maxAreaDataGridViewTextBoxColumn
            // 
            this.maxAreaDataGridViewTextBoxColumn.DataPropertyName = "MaxArea";
            this.maxAreaDataGridViewTextBoxColumn.HeaderText = "MaxArea";
            this.maxAreaDataGridViewTextBoxColumn.Name = "maxAreaDataGridViewTextBoxColumn";
            // 
            // landdemandsBindingSource
            // 
            this.landdemandsBindingSource.DataMember = "land-demands";
            this.landdemandsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // nedvjDataSet
            // 
            this.nedvjDataSet.DataSetName = "nedvjDataSet";
            this.nedvjDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // land_demandsTableAdapter
            // 
            this.land_demandsTableAdapter.ClearBeforeFill = true;
            // 
            // nedvjDataSet1
            // 
            this.nedvjDataSet1.DataSetName = "nedvjDataSet1";
            this.nedvjDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // landdemandsBindingSource1
            // 
            this.landdemandsBindingSource1.DataMember = "land-demands";
            this.landdemandsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // land_demandsTableAdapter1
            // 
            this.land_demandsTableAdapter1.ClearBeforeFill = true;
            // 
            // landsv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(929, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "landsv";
            this.Text = "Просмотр потребностей на земли";
            this.Load += new System.EventHandler(this.landsv_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.landdemandsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.landdemandsBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private nedvjDataSet nedvjDataSet;
        private System.Windows.Forms.BindingSource landdemandsBindingSource;
        private nedvjDataSetTableAdapters.land_demandsTableAdapter land_demandsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressStreetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressHouseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn minPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maxPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn agentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn minAreaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maxAreaDataGridViewTextBoxColumn;
        private nedvjDataSet1 nedvjDataSet1;
        private System.Windows.Forms.BindingSource landdemandsBindingSource1;
        private nedvjDataSet1TableAdapters.land_demandsTableAdapter land_demandsTableAdapter1;
    }
}