﻿
namespace Nedvij.Potreb
{
    partial class potrebapart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backbtn = new System.Windows.Forms.Button();
            this.apartbtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.minromtxt = new System.Windows.Forms.TextBox();
            this.arealbl = new System.Windows.Forms.Label();
            this.maxromtxt = new System.Windows.Forms.TextBox();
            this.numhlbl = new System.Windows.Forms.Label();
            this.numbhtxt = new System.Windows.Forms.TextBox();
            this.strlbl = new System.Windows.Forms.Label();
            this.strtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Adresstxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.minprtxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.maxprtxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.minareatxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.maxareatxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.minflortxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.maxflortxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.agentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nedvjDataSet = new nedvjDataSet();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.clientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.agentsTableAdapter = new nedvjDataSetTableAdapters.agentsTableAdapter();
            this.clientsTableAdapter = new nedvjDataSetTableAdapters.clientsTableAdapter();
            this.nedvjDataSet1 = new nedvjDataSet1();
            this.agentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.agentsTableAdapter1 = new nedvjDataSet1TableAdapters.agentsTableAdapter();
            this.clientsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.clientsTableAdapter1 = new nedvjDataSet1TableAdapters.clientsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(6, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(399, 27);
            this.label1.TabIndex = 31;
            this.label1.Text = "Добавление потребности на квартиру";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(27, 38);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(11, 594);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 57;
            this.backbtn.Text = "Вернуться на главную";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // apartbtn
            // 
            this.apartbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.apartbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apartbtn.Location = new System.Drawing.Point(275, 561);
            this.apartbtn.Name = "apartbtn";
            this.apartbtn.Size = new System.Drawing.Size(105, 47);
            this.apartbtn.TabIndex = 56;
            this.apartbtn.Text = "Добавить квартиру";
            this.apartbtn.UseVisualStyleBackColor = false;
            this.apartbtn.Click += new System.EventHandler(this.apartbtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(106, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 19);
            this.label3.TabIndex = 55;
            this.label3.Text = "Минимум комнат:";
            // 
            // minromtxt
            // 
            this.minromtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minromtxt.Location = new System.Drawing.Point(243, 384);
            this.minromtxt.Name = "minromtxt";
            this.minromtxt.Size = new System.Drawing.Size(215, 26);
            this.minromtxt.TabIndex = 54;
            // 
            // arealbl
            // 
            this.arealbl.AutoSize = true;
            this.arealbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.arealbl.Location = new System.Drawing.Point(103, 423);
            this.arealbl.Name = "arealbl";
            this.arealbl.Size = new System.Drawing.Size(134, 19);
            this.arealbl.TabIndex = 53;
            this.arealbl.Text = "Максимум комнат:";
            // 
            // maxromtxt
            // 
            this.maxromtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maxromtxt.Location = new System.Drawing.Point(243, 416);
            this.maxromtxt.Name = "maxromtxt";
            this.maxromtxt.Size = new System.Drawing.Size(215, 26);
            this.maxromtxt.TabIndex = 52;
            // 
            // numhlbl
            // 
            this.numhlbl.AutoSize = true;
            this.numhlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numhlbl.Location = new System.Drawing.Point(145, 226);
            this.numhlbl.Name = "numhlbl";
            this.numhlbl.Size = new System.Drawing.Size(93, 19);
            this.numhlbl.TabIndex = 51;
            this.numhlbl.Text = "Номер дома:";
            // 
            // numbhtxt
            // 
            this.numbhtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbhtxt.Location = new System.Drawing.Point(243, 223);
            this.numbhtxt.Name = "numbhtxt";
            this.numbhtxt.Size = new System.Drawing.Size(215, 26);
            this.numbhtxt.TabIndex = 50;
            // 
            // strlbl
            // 
            this.strlbl.AutoSize = true;
            this.strlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strlbl.Location = new System.Drawing.Point(184, 198);
            this.strlbl.Name = "strlbl";
            this.strlbl.Size = new System.Drawing.Size(54, 19);
            this.strlbl.TabIndex = 49;
            this.strlbl.Text = "Улица:";
            // 
            // strtxt
            // 
            this.strtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.strtxt.Location = new System.Drawing.Point(243, 191);
            this.strtxt.Name = "strtxt";
            this.strtxt.Size = new System.Drawing.Size(215, 26);
            this.strtxt.TabIndex = 48;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(184, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 47;
            this.label2.Text = "Адрес:";
            // 
            // Adresstxt
            // 
            this.Adresstxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Adresstxt.Location = new System.Drawing.Point(243, 159);
            this.Adresstxt.Name = "Adresstxt";
            this.Adresstxt.Size = new System.Drawing.Size(215, 26);
            this.Adresstxt.TabIndex = 46;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(57, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 19);
            this.label4.TabIndex = 59;
            this.label4.Text = "Минимальная стоимость:";
            // 
            // minprtxt
            // 
            this.minprtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minprtxt.Location = new System.Drawing.Point(243, 258);
            this.minprtxt.Name = "minprtxt";
            this.minprtxt.Size = new System.Drawing.Size(215, 26);
            this.minprtxt.TabIndex = 58;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(54, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 19);
            this.label5.TabIndex = 61;
            this.label5.Text = "Максимальная стоимость:";
            // 
            // maxprtxt
            // 
            this.maxprtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maxprtxt.Location = new System.Drawing.Point(243, 290);
            this.maxprtxt.Name = "maxprtxt";
            this.maxprtxt.Size = new System.Drawing.Size(215, 26);
            this.maxprtxt.TabIndex = 60;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(67, 329);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 19);
            this.label6.TabIndex = 63;
            this.label6.Text = "Минимальная площадь:";
            // 
            // minareatxt
            // 
            this.minareatxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minareatxt.Location = new System.Drawing.Point(243, 322);
            this.minareatxt.Name = "minareatxt";
            this.minareatxt.Size = new System.Drawing.Size(215, 26);
            this.minareatxt.TabIndex = 62;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(64, 357);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 19);
            this.label7.TabIndex = 65;
            this.label7.Text = "Максимальная площадь:";
            // 
            // maxareatxt
            // 
            this.maxareatxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maxareatxt.Location = new System.Drawing.Point(243, 354);
            this.maxareatxt.Name = "maxareatxt";
            this.maxareatxt.Size = new System.Drawing.Size(215, 26);
            this.maxareatxt.TabIndex = 64;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(71, 458);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 19);
            this.label8.TabIndex = 69;
            this.label8.Text = "Минимальный этаж:";
            // 
            // minflortxt
            // 
            this.minflortxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minflortxt.Location = new System.Drawing.Point(243, 451);
            this.minflortxt.Name = "minflortxt";
            this.minflortxt.Size = new System.Drawing.Size(215, 26);
            this.minflortxt.TabIndex = 68;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(68, 490);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 19);
            this.label9.TabIndex = 67;
            this.label9.Text = "Максимальный этаж:";
            // 
            // maxflortxt
            // 
            this.maxflortxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maxflortxt.Location = new System.Drawing.Point(243, 483);
            this.maxflortxt.Name = "maxflortxt";
            this.maxflortxt.Size = new System.Drawing.Size(215, 26);
            this.maxflortxt.TabIndex = 66;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(403, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 19);
            this.label10.TabIndex = 71;
            this.label10.Text = "Номер риэтора:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(403, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 19);
            this.label11.TabIndex = 73;
            this.label11.Text = "Номер клиента:";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.agentsBindingSource1;
            this.comboBox1.DisplayMember = "Id";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(523, 67);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(81, 21);
            this.comboBox1.TabIndex = 74;
            // 
            // agentsBindingSource
            // 
            this.agentsBindingSource.DataMember = "agents";
            this.agentsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // nedvjDataSet
            // 
            this.nedvjDataSet.DataSetName = "nedvjDataSet";
            this.nedvjDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.clientsBindingSource1;
            this.comboBox2.DisplayMember = "Id";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(524, 98);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(80, 21);
            this.comboBox2.TabIndex = 75;
            // 
            // clientsBindingSource
            // 
            this.clientsBindingSource.DataMember = "clients";
            this.clientsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // agentsTableAdapter
            // 
            this.agentsTableAdapter.ClearBeforeFill = true;
            // 
            // clientsTableAdapter
            // 
            this.clientsTableAdapter.ClearBeforeFill = true;
            // 
            // nedvjDataSet1
            // 
            this.nedvjDataSet1.DataSetName = "nedvjDataSet1";
            this.nedvjDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // agentsBindingSource1
            // 
            this.agentsBindingSource1.DataMember = "agents";
            this.agentsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // agentsTableAdapter1
            // 
            this.agentsTableAdapter1.ClearBeforeFill = true;
            // 
            // clientsBindingSource1
            // 
            this.clientsBindingSource1.DataMember = "clients";
            this.clientsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // clientsTableAdapter1
            // 
            this.clientsTableAdapter1.ClearBeforeFill = true;
            // 
            // potrebapart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(616, 653);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.minflortxt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.maxflortxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.maxareatxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.minareatxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.maxprtxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.minprtxt);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.apartbtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.minromtxt);
            this.Controls.Add(this.arealbl);
            this.Controls.Add(this.maxromtxt);
            this.Controls.Add(this.numhlbl);
            this.Controls.Add(this.numbhtxt);
            this.Controls.Add(this.strlbl);
            this.Controls.Add(this.strtxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Adresstxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "potrebapart";
            this.Text = "Потребность на квартиру";
            this.Load += new System.EventHandler(this.potrebapart_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Button apartbtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox minromtxt;
        private System.Windows.Forms.Label arealbl;
        private System.Windows.Forms.TextBox maxromtxt;
        private System.Windows.Forms.Label numhlbl;
        private System.Windows.Forms.TextBox numbhtxt;
        private System.Windows.Forms.Label strlbl;
        private System.Windows.Forms.TextBox strtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Adresstxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox minprtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox maxprtxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox minareatxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox maxareatxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox minflortxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox maxflortxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private nedvjDataSet nedvjDataSet;
        private System.Windows.Forms.BindingSource agentsBindingSource;
        private nedvjDataSetTableAdapters.agentsTableAdapter agentsTableAdapter;
        private System.Windows.Forms.BindingSource clientsBindingSource;
        private nedvjDataSetTableAdapters.clientsTableAdapter clientsTableAdapter;
        private nedvjDataSet1 nedvjDataSet1;
        private System.Windows.Forms.BindingSource agentsBindingSource1;
        private nedvjDataSet1TableAdapters.agentsTableAdapter agentsTableAdapter1;
        private System.Windows.Forms.BindingSource clientsBindingSource1;
        private nedvjDataSet1TableAdapters.clientsTableAdapter clientsTableAdapter1;
    }
}