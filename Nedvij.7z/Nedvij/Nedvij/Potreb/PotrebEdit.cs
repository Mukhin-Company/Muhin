﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Potreb
{
    public partial class PotrebEdit : Form
    {
        public PotrebEdit()
        {
            InitializeComponent();
        }

        private void landbtn_Click(object sender, EventArgs e)
        {
            Form a = new Potreb.landsv();
                a.Show();
            this.Close();
        }

        private void apartbtn_Click(object sender, EventArgs e)
        {
            Form a = new Potreb.apartv();
            a.Show();
            this.Close();
        }

        private void housebtn_Click(object sender, EventArgs e)
        {
            Form a = new Potreb.housev();
            a.Show();
            this.Close();
        }
    }
}
