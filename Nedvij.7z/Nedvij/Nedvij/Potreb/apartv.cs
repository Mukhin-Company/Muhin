﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Potreb
{
    public partial class apartv : Form
    {
        public apartv()
        {
            InitializeComponent();
        }

        private void apartv_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1._apartment_demands". При необходимости она может быть перемещена или удалена.
            this.apartment_demandsTableAdapter1.Fill(this.nedvjDataSet1._apartment_demands);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet._apartment_demands". При необходимости она может быть перемещена или удалена.

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }
    }
}
