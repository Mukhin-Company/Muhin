﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nedvij.Potreb
{
    public partial class potrebland : Form
    {
        public potrebland()
        {
            InitializeComponent();
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }

        private void apartbtn_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.nedvjConnectionString1))
            {
                string str = @"Data Source=COMP3-A7\SQLEXPRESS;Initial Catalog=nedvj;Integrated Security=True";
                SqlConnection connection = new SqlConnection(str);
                connection.Open();

                SqlCommand command_insertClient = new SqlCommand("Insert into [land-demands](Address_City,Address_Street,MinPrice,MaxPrice,AgentId,ClientId,MinArea,MaxArea)" +
                    "Values(@Adress,@Ylica,@MinP,@MaxP,@AID,@CID,@MinA,@MaxA)", connection);
                command_insertClient.Parameters.AddWithValue("@Adress", Adresstxt.Text);
                command_insertClient.Parameters.AddWithValue("@Ylica", strtxt.Text);
                command_insertClient.Parameters.AddWithValue("@MinP", minprtxt.Text);
                command_insertClient.Parameters.AddWithValue("@MaxP", maxprtxt.Text);
                command_insertClient.Parameters.AddWithValue("@AID", comboBox1.Text);
                command_insertClient.Parameters.AddWithValue("@CID", comboBox2.Text);
                command_insertClient.Parameters.AddWithValue("@MinA", minareatxt.Text);
                command_insertClient.Parameters.AddWithValue("@MaxA", maxareatxt.Text);

                command_insertClient.ExecuteNonQuery()
;
                try
                {
                    MessageBox.Show("Добавление потребности на землю успешно", "Добавление");
                }
                catch
                {
                    MessageBox.Show("Проверьте введенные ланные!", "Ошибка");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void potrebland_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.clients". При необходимости она может быть перемещена или удалена.
            this.clientsTableAdapter1.Fill(this.nedvjDataSet1.clients);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.agents". При необходимости она может быть перемещена или удалена.
            this.agentsTableAdapter1.Fill(this.nedvjDataSet1.agents);


        }
    }
}
