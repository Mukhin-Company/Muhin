﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Potreb
{
    public partial class housev : Form
    {
        public housev()
        {
            InitializeComponent();
        }

        private void housev_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1._house_demands". При необходимости она может быть перемещена или удалена.
            this.house_demandsTableAdapter1.Fill(this.nedvjDataSet1._house_demands);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet._house_demands". При необходимости она может быть перемещена или удалена.

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }
    }
}
