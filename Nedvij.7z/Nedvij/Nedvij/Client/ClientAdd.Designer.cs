﻿
namespace Nedvij.Client
{
    partial class ClientAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.famtxt = new System.Windows.Forms.TextBox();
            this.famlbl = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.namelbl = new System.Windows.Forms.Label();
            this.otchlbl = new System.Windows.Forms.Label();
            this.otchtxt = new System.Windows.Forms.TextBox();
            this.numbertxt = new System.Windows.Forms.TextBox();
            this.mailtxt = new System.Windows.Forms.TextBox();
            this.numblbl = new System.Windows.Forms.Label();
            this.maillbl = new System.Windows.Forms.Label();
            this.addbtn = new System.Windows.Forms.Button();
            this.reglbl = new System.Windows.Forms.Label();
            this.backbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(127, 57);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // famtxt
            // 
            this.famtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.famtxt.Location = new System.Drawing.Point(172, 182);
            this.famtxt.Name = "famtxt";
            this.famtxt.Size = new System.Drawing.Size(181, 26);
            this.famtxt.TabIndex = 1;
            // 
            // famlbl
            // 
            this.famlbl.AutoSize = true;
            this.famlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.famlbl.Location = new System.Drawing.Point(91, 185);
            this.famlbl.Name = "famlbl";
            this.famlbl.Size = new System.Drawing.Size(75, 19);
            this.famlbl.TabIndex = 2;
            this.famlbl.Text = "Фамилия:";
            // 
            // nametxt
            // 
            this.nametxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nametxt.Location = new System.Drawing.Point(172, 229);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(181, 26);
            this.nametxt.TabIndex = 3;
            // 
            // namelbl
            // 
            this.namelbl.AutoSize = true;
            this.namelbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.namelbl.Location = new System.Drawing.Point(120, 229);
            this.namelbl.Name = "namelbl";
            this.namelbl.Size = new System.Drawing.Size(40, 19);
            this.namelbl.TabIndex = 4;
            this.namelbl.Text = "Имя:";
            // 
            // otchlbl
            // 
            this.otchlbl.AutoSize = true;
            this.otchlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.otchlbl.Location = new System.Drawing.Point(58, 260);
            this.otchlbl.Name = "otchlbl";
            this.otchlbl.Size = new System.Drawing.Size(108, 38);
            this.otchlbl.TabIndex = 5;
            this.otchlbl.Text = "Отчество:\r\n(при наличии)";
            // 
            // otchtxt
            // 
            this.otchtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.otchtxt.Location = new System.Drawing.Point(172, 272);
            this.otchtxt.Name = "otchtxt";
            this.otchtxt.Size = new System.Drawing.Size(181, 26);
            this.otchtxt.TabIndex = 6;
            // 
            // numbertxt
            // 
            this.numbertxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbertxt.Location = new System.Drawing.Point(172, 315);
            this.numbertxt.Name = "numbertxt";
            this.numbertxt.Size = new System.Drawing.Size(181, 26);
            this.numbertxt.TabIndex = 7;
            // 
            // mailtxt
            // 
            this.mailtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mailtxt.Location = new System.Drawing.Point(172, 360);
            this.mailtxt.Name = "mailtxt";
            this.mailtxt.Size = new System.Drawing.Size(181, 26);
            this.mailtxt.TabIndex = 8;
            // 
            // numblbl
            // 
            this.numblbl.AutoSize = true;
            this.numblbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numblbl.Location = new System.Drawing.Point(44, 322);
            this.numblbl.Name = "numblbl";
            this.numblbl.Size = new System.Drawing.Size(122, 19);
            this.numblbl.TabIndex = 9;
            this.numblbl.Text = "Номер телефона:";
            // 
            // maillbl
            // 
            this.maillbl.AutoSize = true;
            this.maillbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maillbl.Location = new System.Drawing.Point(17, 363);
            this.maillbl.Name = "maillbl";
            this.maillbl.Size = new System.Drawing.Size(143, 19);
            this.maillbl.TabIndex = 10;
            this.maillbl.Text = "Электронная почта:";
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addbtn.Location = new System.Drawing.Point(199, 412);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(105, 47);
            this.addbtn.TabIndex = 11;
            this.addbtn.Text = "Добавить клиента";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // reglbl
            // 
            this.reglbl.AutoSize = true;
            this.reglbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.reglbl.Location = new System.Drawing.Point(123, 18);
            this.reglbl.Name = "reglbl";
            this.reglbl.Size = new System.Drawing.Size(261, 23);
            this.reglbl.TabIndex = 12;
            this.reglbl.Text = "Регистрация нового клиента";
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(12, 465);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 13;
            this.backbtn.Text = "Вернуться на главный";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // ClientAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(466, 524);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.reglbl);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.maillbl);
            this.Controls.Add(this.numblbl);
            this.Controls.Add(this.mailtxt);
            this.Controls.Add(this.numbertxt);
            this.Controls.Add(this.otchtxt);
            this.Controls.Add(this.otchlbl);
            this.Controls.Add(this.namelbl);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.famlbl);
            this.Controls.Add(this.famtxt);
            this.Controls.Add(this.pictureBox1);
            this.Name = "ClientAdd";
            this.Text = "Регистрация нового клиента";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox famtxt;
        private System.Windows.Forms.Label famlbl;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label namelbl;
        private System.Windows.Forms.Label otchlbl;
        private System.Windows.Forms.TextBox otchtxt;
        private System.Windows.Forms.TextBox numbertxt;
        private System.Windows.Forms.TextBox mailtxt;
        private System.Windows.Forms.Label numblbl;
        private System.Windows.Forms.Label maillbl;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.Label reglbl;
        private System.Windows.Forms.Button backbtn;
    }
}