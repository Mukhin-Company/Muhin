﻿namespace Nedvij
{


    partial class nedvjDataSet
    {
    }
}
