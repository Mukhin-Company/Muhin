﻿
namespace Nedvij.Rielt
{
    partial class RieltAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reglbl = new System.Windows.Forms.Label();
            this.deallbl = new System.Windows.Forms.Label();
            this.dealtxt = new System.Windows.Forms.TextBox();
            this.otchtxt = new System.Windows.Forms.TextBox();
            this.otchlbl = new System.Windows.Forms.Label();
            this.namelbl = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.famlbl = new System.Windows.Forms.Label();
            this.famtxt = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.addbtn = new System.Windows.Forms.Button();
            this.backbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // reglbl
            // 
            this.reglbl.AutoSize = true;
            this.reglbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.reglbl.Location = new System.Drawing.Point(96, 9);
            this.reglbl.Name = "reglbl";
            this.reglbl.Size = new System.Drawing.Size(271, 23);
            this.reglbl.TabIndex = 22;
            this.reglbl.Text = "Регистрация нового риэлтора";
            // 
            // deallbl
            // 
            this.deallbl.AutoSize = true;
            this.deallbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deallbl.Location = new System.Drawing.Point(8, 314);
            this.deallbl.Name = "deallbl";
            this.deallbl.Size = new System.Drawing.Size(134, 19);
            this.deallbl.TabIndex = 21;
            this.deallbl.Text = "Доля от комиссии:";
            // 
            // dealtxt
            // 
            this.dealtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dealtxt.Location = new System.Drawing.Point(148, 307);
            this.dealtxt.Name = "dealtxt";
            this.dealtxt.Size = new System.Drawing.Size(181, 26);
            this.dealtxt.TabIndex = 20;
            // 
            // otchtxt
            // 
            this.otchtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.otchtxt.Location = new System.Drawing.Point(148, 264);
            this.otchtxt.Name = "otchtxt";
            this.otchtxt.Size = new System.Drawing.Size(181, 26);
            this.otchtxt.TabIndex = 19;
            // 
            // otchlbl
            // 
            this.otchlbl.AutoSize = true;
            this.otchlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.otchlbl.Location = new System.Drawing.Point(34, 252);
            this.otchlbl.Name = "otchlbl";
            this.otchlbl.Size = new System.Drawing.Size(108, 38);
            this.otchlbl.TabIndex = 18;
            this.otchlbl.Text = "Отчество:\r\n(при наличии)";
            // 
            // namelbl
            // 
            this.namelbl.AutoSize = true;
            this.namelbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.namelbl.Location = new System.Drawing.Point(96, 221);
            this.namelbl.Name = "namelbl";
            this.namelbl.Size = new System.Drawing.Size(40, 19);
            this.namelbl.TabIndex = 17;
            this.namelbl.Text = "Имя:";
            // 
            // nametxt
            // 
            this.nametxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nametxt.Location = new System.Drawing.Point(148, 221);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(181, 26);
            this.nametxt.TabIndex = 16;
            // 
            // famlbl
            // 
            this.famlbl.AutoSize = true;
            this.famlbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.famlbl.Location = new System.Drawing.Point(67, 177);
            this.famlbl.Name = "famlbl";
            this.famlbl.Size = new System.Drawing.Size(75, 19);
            this.famlbl.TabIndex = 15;
            this.famlbl.Text = "Фамилия:";
            // 
            // famtxt
            // 
            this.famtxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.famtxt.Location = new System.Drawing.Point(148, 174);
            this.famtxt.Name = "famtxt";
            this.famtxt.Size = new System.Drawing.Size(181, 26);
            this.famtxt.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(100, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addbtn.Location = new System.Drawing.Point(179, 350);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(105, 47);
            this.addbtn.TabIndex = 23;
            this.addbtn.Text = "Добавить риэтора";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.backbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backbtn.Location = new System.Drawing.Point(317, 391);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(105, 47);
            this.backbtn.TabIndex = 24;
            this.backbtn.Text = "Вернуться на главный";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // RieltAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(434, 450);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.reglbl);
            this.Controls.Add(this.deallbl);
            this.Controls.Add(this.dealtxt);
            this.Controls.Add(this.otchtxt);
            this.Controls.Add(this.otchlbl);
            this.Controls.Add(this.namelbl);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.famlbl);
            this.Controls.Add(this.famtxt);
            this.Controls.Add(this.pictureBox1);
            this.Name = "RieltAdd";
            this.Text = "Регистрация нового риэлтора";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label reglbl;
        private System.Windows.Forms.Label deallbl;
        private System.Windows.Forms.TextBox dealtxt;
        private System.Windows.Forms.TextBox otchtxt;
        private System.Windows.Forms.Label otchlbl;
        private System.Windows.Forms.Label namelbl;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label famlbl;
        private System.Windows.Forms.TextBox famtxt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.Button backbtn;
    }
}