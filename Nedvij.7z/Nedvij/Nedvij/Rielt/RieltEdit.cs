﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Rielt
{
    public partial class RieltEdit : Form
    {
        public RieltEdit()
        {
            InitializeComponent();
        }

        private void RieltEdit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.agents". При необходимости она может быть перемещена или удалена.
            this.agentsTableAdapter1.Fill(this.nedvjDataSet1.agents);

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            Close();
        }

        private void filtrbtn_Click(object sender, EventArgs e)
        {
            agentsBindingSource.Filter = "[FirstName] Like'" + textBox1.Text + "%'";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Сохранено","Успешно");
            agentsTableAdapter1.Update(this.nedvjDataSet1.agents);
        }
    }
}
