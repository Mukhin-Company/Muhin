﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nedvij.Rielt
{
    public partial class RieltAdd : Form
    {
        public RieltAdd()
        {
            InitializeComponent();
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.nedvjConnectionString1))
            {
                string str = @"Data Source=COMP3-A7\SQLEXPRESS;Initial Catalog=nedvj;Integrated Security=True";
                SqlConnection connection = new SqlConnection(str);
                connection.Open();

                SqlCommand command_insertClient = new SqlCommand("Insert into [agents](FirstName,MiddleName,LastName,DealShare)" +
                    "Values(@Fam,@Name,@Otch,@Deal)", connection);
                command_insertClient.Parameters.AddWithValue("@Fam", famtxt.Text);
                command_insertClient.Parameters.AddWithValue("@Name", nametxt.Text);
                command_insertClient.Parameters.AddWithValue("@Otch", otchtxt.Text);
                command_insertClient.Parameters.AddWithValue("@Deal", dealtxt.Text);
                command_insertClient.ExecuteNonQuery()
;
                try
                {
                    MessageBox.Show("Добавление риелтора успешно", "Добавление");
                }
                catch
                {
                    MessageBox.Show("Проверьте введенные ланные!", "Ошибка");
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
