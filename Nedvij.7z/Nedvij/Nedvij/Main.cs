﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void создатьКлиентаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Client.ClientAdd();
            a.Show();
            this.Hide();
        }

        private void изменениеИнфКлиентаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form A = new ClientEd();
            A.Show();
            this.Hide();
        }

        private void новыйРиэлторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Rielt.RieltAdd();
            a.Show();
            this.Hide();


        }

        private void изменениеИнфриэлтораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Rielt.RieltEdit();
            a.Show();
            this.Hide();
        }

        private void создатьОбъектНедвижимостиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Nedvij.NedvAdd();
            a.Show();
            this.Hide();
        }

        private void редактироватьОбъектНедвижимостиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Nedvij.NedvEdit();
            a.Show();
            this.Hide();

        }

        private void создатьПредложениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Predloj.PredlojAdd();
            a.Show();
            this.Hide();
        }

        private void редактироватьПредложениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Predloj.PredlojEdit();
            a.Show();
            this.Hide();
        }

        private void создатьПотребностьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Potreb.PotrebAdd();
            a.Show();
            this.Hide();
        }

        private void редактироватьПотребностьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form a = new Potreb.PotrebEdit();
            a.Show();
            this.Hide();
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {

        }
    }
}
