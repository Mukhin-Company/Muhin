﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nedvij.Predloj
{
    public partial class PredlojEdit : Form
    {
        public PredlojEdit()
        {
            InitializeComponent();
        }

        private void PredlojEdit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.supplies". При необходимости она может быть перемещена или удалена.
            this.suppliesTableAdapter1.Fill(this.nedvjDataSet1.supplies);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet.supplies". При необходимости она может быть перемещена или удалена.

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }
    }
}
