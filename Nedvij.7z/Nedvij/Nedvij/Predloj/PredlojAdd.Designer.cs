﻿
namespace Nedvij.Predloj
{
    partial class PredlojAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rieltcb = new System.Windows.Forms.ComboBox();
            this.agentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nedvjDataSet = new nedvjDataSet();
            this.clientcb = new System.Windows.Forms.ComboBox();
            this.clientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nedvijcb = new System.Windows.Forms.ComboBox();
            this.apartBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pricetxt = new System.Windows.Forms.TextBox();
            this.riellbl = new System.Windows.Forms.Label();
            this.clientlbl = new System.Windows.Forms.Label();
            this.nedvjlbl = new System.Windows.Forms.Label();
            this.pricelbl = new System.Windows.Forms.Label();
            this.homebtn = new System.Windows.Forms.Button();
            this.addbtn = new System.Windows.Forms.Button();
            this.agentsTableAdapter = new nedvjDataSetTableAdapters.agentsTableAdapter();
            this.clientsTableAdapter = new nedvjDataSetTableAdapters.clientsTableAdapter();
            this.apartTableAdapter = new nedvjDataSetTableAdapters.apartTableAdapter();
            this.nedvjDataSet1 = new nedvjDataSet1();
            this.agentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.agentsTableAdapter1 = new nedvjDataSet1TableAdapters.agentsTableAdapter();
            this.clientsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.clientsTableAdapter1 = new nedvjDataSet1TableAdapters.clientsTableAdapter();
            this.apartBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.apartTableAdapter1 = new nedvjDataSet1TableAdapters.apartTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(25, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 27);
            this.label1.TabIndex = 8;
            this.label1.Text = "Добавление предложения ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Nedvij.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(30, 43);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // rieltcb
            // 
            this.rieltcb.DataSource = this.agentsBindingSource1;
            this.rieltcb.DisplayMember = "Id";
            this.rieltcb.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.rieltcb.FormattingEnabled = true;
            this.rieltcb.Location = new System.Drawing.Point(199, 164);
            this.rieltcb.Name = "rieltcb";
            this.rieltcb.Size = new System.Drawing.Size(168, 27);
            this.rieltcb.TabIndex = 9;
            // 
            // agentsBindingSource
            // 
            this.agentsBindingSource.DataMember = "agents";
            this.agentsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // nedvjDataSet
            // 
            this.nedvjDataSet.DataSetName = "nedvjDataSet";
            this.nedvjDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientcb
            // 
            this.clientcb.DataSource = this.clientsBindingSource1;
            this.clientcb.DisplayMember = "Id";
            this.clientcb.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.clientcb.FormattingEnabled = true;
            this.clientcb.Location = new System.Drawing.Point(199, 205);
            this.clientcb.Name = "clientcb";
            this.clientcb.Size = new System.Drawing.Size(168, 27);
            this.clientcb.TabIndex = 10;
            // 
            // clientsBindingSource
            // 
            this.clientsBindingSource.DataMember = "clients";
            this.clientsBindingSource.DataSource = this.nedvjDataSet;
            // 
            // nedvijcb
            // 
            this.nedvijcb.DataSource = this.apartBindingSource1;
            this.nedvijcb.DisplayMember = "Id";
            this.nedvijcb.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.nedvijcb.FormattingEnabled = true;
            this.nedvijcb.Location = new System.Drawing.Point(199, 246);
            this.nedvijcb.Name = "nedvijcb";
            this.nedvijcb.Size = new System.Drawing.Size(168, 27);
            this.nedvijcb.TabIndex = 11;
            // 
            // apartBindingSource
            // 
            this.apartBindingSource.DataMember = "apart";
            this.apartBindingSource.DataSource = this.nedvjDataSet;
            // 
            // pricetxt
            // 
            this.pricetxt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pricetxt.Location = new System.Drawing.Point(199, 289);
            this.pricetxt.Name = "pricetxt";
            this.pricetxt.Size = new System.Drawing.Size(168, 26);
            this.pricetxt.TabIndex = 12;
            // 
            // riellbl
            // 
            this.riellbl.AutoSize = true;
            this.riellbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.riellbl.Location = new System.Drawing.Point(125, 166);
            this.riellbl.Name = "riellbl";
            this.riellbl.Size = new System.Drawing.Size(68, 19);
            this.riellbl.TabIndex = 13;
            this.riellbl.Text = "Риэлтор:";
            // 
            // clientlbl
            // 
            this.clientlbl.AutoSize = true;
            this.clientlbl.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.clientlbl.Location = new System.Drawing.Point(130, 207);
            this.clientlbl.Name = "clientlbl";
            this.clientlbl.Size = new System.Drawing.Size(63, 19);
            this.clientlbl.TabIndex = 14;
            this.clientlbl.Text = "Клиент:";
            // 
            // nedvjlbl
            // 
            this.nedvjlbl.AutoSize = true;
            this.nedvjlbl.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.nedvjlbl.Location = new System.Drawing.Point(26, 248);
            this.nedvjlbl.Name = "nedvjlbl";
            this.nedvjlbl.Size = new System.Drawing.Size(167, 19);
            this.nedvjlbl.TabIndex = 15;
            this.nedvjlbl.Text = "Объект недвижимости:";
            // 
            // pricelbl
            // 
            this.pricelbl.AutoSize = true;
            this.pricelbl.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.pricelbl.Location = new System.Drawing.Point(147, 290);
            this.pricelbl.Name = "pricelbl";
            this.pricelbl.Size = new System.Drawing.Size(46, 19);
            this.pricelbl.TabIndex = 16;
            this.pricelbl.Text = "Цена:";
            // 
            // homebtn
            // 
            this.homebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.homebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.homebtn.Location = new System.Drawing.Point(12, 391);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(105, 47);
            this.homebtn.TabIndex = 31;
            this.homebtn.Text = "Домой";
            this.homebtn.UseVisualStyleBackColor = false;
            this.homebtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.addbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addbtn.Location = new System.Drawing.Point(217, 333);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(122, 63);
            this.addbtn.TabIndex = 32;
            this.addbtn.Text = "Добавить предложение";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // agentsTableAdapter
            // 
            this.agentsTableAdapter.ClearBeforeFill = true;
            // 
            // clientsTableAdapter
            // 
            this.clientsTableAdapter.ClearBeforeFill = true;
            // 
            // apartTableAdapter
            // 
            this.apartTableAdapter.ClearBeforeFill = true;
            // 
            // nedvjDataSet1
            // 
            this.nedvjDataSet1.DataSetName = "nedvjDataSet1";
            this.nedvjDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // agentsBindingSource1
            // 
            this.agentsBindingSource1.DataMember = "agents";
            this.agentsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // agentsTableAdapter1
            // 
            this.agentsTableAdapter1.ClearBeforeFill = true;
            // 
            // clientsBindingSource1
            // 
            this.clientsBindingSource1.DataMember = "clients";
            this.clientsBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // clientsTableAdapter1
            // 
            this.clientsTableAdapter1.ClearBeforeFill = true;
            // 
            // apartBindingSource1
            // 
            this.apartBindingSource1.DataMember = "apart";
            this.apartBindingSource1.DataSource = this.nedvjDataSet1;
            // 
            // apartTableAdapter1
            // 
            this.apartTableAdapter1.ClearBeforeFill = true;
            // 
            // PredlojAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(534, 450);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.homebtn);
            this.Controls.Add(this.pricelbl);
            this.Controls.Add(this.nedvjlbl);
            this.Controls.Add(this.clientlbl);
            this.Controls.Add(this.riellbl);
            this.Controls.Add(this.pricetxt);
            this.Controls.Add(this.nedvijcb);
            this.Controls.Add(this.clientcb);
            this.Controls.Add(this.rieltcb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "PredlojAdd";
            this.Text = "Добавление предложения";
            this.Load += new System.EventHandler(this.PredlojAdd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nedvjDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox rieltcb;
        private System.Windows.Forms.ComboBox clientcb;
        private System.Windows.Forms.ComboBox nedvijcb;
        private System.Windows.Forms.TextBox pricetxt;
        private System.Windows.Forms.Label riellbl;
        private System.Windows.Forms.Label clientlbl;
        private System.Windows.Forms.Label nedvjlbl;
        private System.Windows.Forms.Label pricelbl;
        private System.Windows.Forms.Button homebtn;
        private System.Windows.Forms.Button addbtn;
        private nedvjDataSet nedvjDataSet;
        private System.Windows.Forms.BindingSource agentsBindingSource;
        private nedvjDataSetTableAdapters.agentsTableAdapter agentsTableAdapter;
        private System.Windows.Forms.BindingSource clientsBindingSource;
        private nedvjDataSetTableAdapters.clientsTableAdapter clientsTableAdapter;
        private System.Windows.Forms.BindingSource apartBindingSource;
        private nedvjDataSetTableAdapters.apartTableAdapter apartTableAdapter;
        private nedvjDataSet1 nedvjDataSet1;
        private System.Windows.Forms.BindingSource agentsBindingSource1;
        private nedvjDataSet1TableAdapters.agentsTableAdapter agentsTableAdapter1;
        private System.Windows.Forms.BindingSource clientsBindingSource1;
        private nedvjDataSet1TableAdapters.clientsTableAdapter clientsTableAdapter1;
        private System.Windows.Forms.BindingSource apartBindingSource1;
        private nedvjDataSet1TableAdapters.apartTableAdapter apartTableAdapter1;
    }
}