﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nedvij.Predloj
{
    public partial class PredlojAdd : Form
    {
        public PredlojAdd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form a = new MainWindow();
            a.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.nedvjConnectionString1))
            {
                string str = @"Data Source=COMP3-A7\SQLEXPRESS;Initial Catalog=nedvj;Integrated Security=True";
                SqlConnection connection = new SqlConnection(str);
                connection.Open();

                SqlCommand command_insertClient = new SqlCommand("Insert into [supplies](Price,AgentId,ClientId,RealEstateId)" +
                    "Values(@Price,@AID,@CID,@Nedvj)", connection);
                command_insertClient.Parameters.AddWithValue("@Price", pricetxt.Text);
                command_insertClient.Parameters.AddWithValue("@AID",  rieltcb.Text);
                command_insertClient.Parameters.AddWithValue("@CID", clientcb.Text);
                command_insertClient.Parameters.AddWithValue("@Nedvj", nedvijcb.Text);
                command_insertClient.ExecuteNonQuery()
;
                try
                {
                    MessageBox.Show("Добавление предложения успешно", "Добавление");
                }
                catch
                {
                    MessageBox.Show("Проверьте введенные ланные!", "Ошибка");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void PredlojAdd_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.apart". При необходимости она может быть перемещена или удалена.
            this.apartTableAdapter1.Fill(this.nedvjDataSet1.apart);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.clients". При необходимости она может быть перемещена или удалена.
            this.clientsTableAdapter1.Fill(this.nedvjDataSet1.clients);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "nedvjDataSet1.agents". При необходимости она может быть перемещена или удалена.
            this.agentsTableAdapter1.Fill(this.nedvjDataSet1.agents);


        }
    }
}
